#!/usr/bin/env bash
# Usage: deploy-update.sh <zip-url-or-path> [target-dir]   (target defaults to ~/firefox-container)
#
# Installs firefox-container on a fresh VM, or upgrades an existing install, from a release zip.
# Same rules as the other stacks' deploy-update.sh:
#   * .env and the Firefox profile (config/) are never overwritten
#   * any other file you hand-edited since the last update is left alone and reported
#     (detected against a baseline snapshot of what was last applied)
#   * new .env keys from .env.example are appended with their defaults; your values stay
#   * nothing is deleted automatically — removed files are only reported
# Then, once a real web password is set in .env, it pulls the latest image, (re)starts the
# container and waits for it to come up. The container is only recreated when the image or
# one of the project files actually changed, so a no-op update doesn't restart your browser.
set -euo pipefail

# Run from a private copy so this script can safely replace its own installed file.
if [[ -z ${FFC_DEPLOY_COPY:-} ]]; then
  self_copy=$(mktemp)
  cp "$0" "$self_copy"
  FFC_DEPLOY_COPY=$self_copy exec bash "$self_copy" "$@"
fi
trap 'rm -f "$FFC_DEPLOY_COPY"' EXIT

PROJECT=firefox-container
SERVICE=firefox
ENV_TEMPLATE=.env.example
PLACEHOLDER_PASSWORD=changeme_strong_password
START_TIMEOUT=${START_TIMEOUT:-180}

for cmd in curl python3 docker; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    [[ $cmd == docker ]] && echo "Install Docker Engine + the compose plugin first." >&2 \
                         || echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done
docker compose version >/dev/null 2>&1 || { echo "The docker compose plugin is missing." >&2; exit 1; }

SOURCE="${1:?Usage: $0 <zip-url-or-path> [target-dir]}"
TARGET_DIR="${2:-$HOME/$PROJECT}"

# Never touched by an update: your secrets, the live Firefox profile, and the baseline itself.
HARD_PROTECTED_PATHS="
.env
.deploy-baseline
config
"
BASELINE_DIR="$TARGET_DIR/.deploy-baseline"

# sha256 of files as shipped in earlier releases (before this script existed). An install
# made from one of those zips has no baseline yet; a file matching one of these is known to be
# unedited, so it's updated instead of being skipped "this once".
KNOWN_RELEASE_HASHES="
f9534fd5e6da0d44000189c595d4be17c3991ee0b63bcc65d9a72993adb06a42 policies/policies.json
540c87cdf49f39300fefcad125109a269ef32554284c7d7ec3aa18b72b6f8b10 docker-compose.yml
50863526c5797b3c56da2acec1edd0c221aa6fafb28b70244e3ae34f65f69608 docker-compose.yml
2526128fb9973edec9124f88c0f540ecfef6a07b4869d45a6ab115d3bb53be0d docker-compose.yml
91a76fc91be921195ab21c2ca395f0e57161915fd7ebfd073603c76b3b799ed5 docker-compose.yml
89eb0cd3ad9be8c1cb5abeeb0e2770a63df41762a95ce1057c55f1560bad527d .env.example
"

is_hard_protected() {
  local path=$1 p
  for p in $HARD_PROTECTED_PATHS; do
    case "$path" in "$p"|"$p"/*) return 0 ;; esac
  done
  return 1
}

is_known_release() { # relpath file
  local h
  h=$(sha256sum "$2" | cut -d' ' -f1)
  grep -qxF "$h $1" <<<"$KNOWN_RELEASE_HASHES"
}

WORK=$(mktemp -d)
trap 'rm -f "$FFC_DEPLOY_COPY"; rm -rf "$WORK"' EXIT
TMP_ZIP="$WORK/release.zip"
TMP_EXTRACT="$WORK/extract"
mkdir -p "$TMP_EXTRACT"

if [[ $SOURCE =~ ^(https?|file):// ]]; then
  echo "==> Downloading $SOURCE"
  curl -fsSL -o "$TMP_ZIP" "$SOURCE"
else
  [[ -f $SOURCE ]] || { echo "Zip not found: $SOURCE" >&2; exit 1; }
  cp "$SOURCE" "$TMP_ZIP"
fi

echo "==> Extracting (stripping the top-level folder)"
python3 -I - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], os.path.realpath(sys.argv[2])
with zipfile.ZipFile(zip_path) as z:
    for info in z.infolist():
        parts = info.filename.split("/", 1)
        if len(parts) < 2 or not parts[1] or info.filename.endswith("/"):
            continue
        target = os.path.realpath(os.path.join(extract_to, parts[1]))
        if not target.startswith(extract_to + os.sep):
            sys.exit(f"refusing unsafe path in zip: {info.filename}")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(z.read(info))
        mode = (info.external_attr >> 16) & 0o777
        if mode:
            os.chmod(target, mode)
PYEOF
[[ -f $TMP_EXTRACT/docker-compose.yml ]] || { echo "This zip doesn't look like a $PROJECT release." >&2; exit 1; }

mkdir -p "$TARGET_DIR" "$BASELINE_DIR"

echo "==> Applying updates"
NEW_LIST="$WORK/new" EDITED_LIST="$WORK/edited" UNTRACKED_LIST="$WORK/untracked" UPDATED_LIST="$WORK/updated"
: > "$NEW_LIST"; : > "$EDITED_LIST"; : > "$UNTRACKED_LIST"; : > "$UPDATED_LIST"
while IFS= read -r relpath; do
  is_hard_protected "$relpath" && continue
  target_file="$TARGET_DIR/$relpath"
  baseline_file="$BASELINE_DIR/$relpath"
  new_file="$TMP_EXTRACT/$relpath"

  if [[ ! -e $target_file ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -p "$new_file" "$target_file"
    echo "$relpath" >> "$NEW_LIST"
  elif { [[ -f $baseline_file ]] && cmp -s "$target_file" "$baseline_file"; } \
       || { [[ ! -f $baseline_file ]] && is_known_release "$relpath" "$target_file"; }; then
    # untouched since the last update (or an unmodified earlier release) — safe to replace
    if ! cmp -s "$new_file" "$target_file"; then
      cp -p "$new_file" "$target_file"
      echo "$relpath" >> "$UPDATED_LIST"
    fi
  elif [[ -f $baseline_file ]]; then
    # you edited it since the last update — leave it
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$EDITED_LIST"
  else
    # pre-existing file with no baseline that doesn't match a known release — leave it this once
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$UNTRACKED_LIST"
  fi
  mkdir -p "$(dirname "$baseline_file")"
  cp -p "$new_file" "$baseline_file"
done < <(cd "$TMP_EXTRACT" && find . -type f | sed 's#^\./##' | sort)

if [[ -s $NEW_LIST ]]; then echo "    New files added:"; sed 's/^/      /' "$NEW_LIST"; fi
if [[ -s $UPDATED_LIST ]]; then echo "    Updated:"; sed 's/^/      /' "$UPDATED_LIST"; fi
if [[ -s $EDITED_LIST ]]; then
  echo "    Hand-edited by you since the last update — left untouched. To see the new version:"
  while IFS= read -r f; do echo "      diff $TARGET_DIR/$f $BASELINE_DIR/$f"; done < "$EDITED_LIST"
fi
if [[ -s $UNTRACKED_LIST ]]; then
  echo "    Differ from the release and couldn't be confirmed as unedited — left alone this once; tracked from now on:"
  while IFS= read -r f; do echo "      $f   (new version: diff $TARGET_DIR/$f $BASELINE_DIR/$f)"; done < "$UNTRACKED_LIST"
fi
[[ -s $NEW_LIST || -s $UPDATED_LIST || -s $EDITED_LIST || -s $UNTRACKED_LIST ]] || echo "    Already up to date."

echo "==> Checking for files this update removed (reported only, nothing deleted)"
ORPHANS=$(cd "$TARGET_DIR" && find . \( -path ./.deploy-baseline -o -path ./config \) -prune -o -type f -print | sed 's#^\./##' | sort | while IFS= read -r f; do
  is_hard_protected "$f" && continue
  [[ -e $BASELINE_DIR/$f && ! -e $TMP_EXTRACT/$f ]] && echo "$f"
done || true)
if [[ -n $ORPHANS ]]; then
  echo "    No longer part of the project — safe to remove:"
  sed "s#^#      rm $TARGET_DIR/#" <<<"$ORPHANS"
  while IFS= read -r f; do rm -f "$BASELINE_DIR/$f"; done <<<"$ORPHANS"
else
  echo "    Nothing orphaned."
fi

echo "==> Merging .env"
if [[ -f $TARGET_DIR/.env && -f $TMP_EXTRACT/$ENV_TEMPLATE ]]; then
  NEW_KEYS=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TARGET_DIR/.env" || NEW_KEYS+="$line"$'\n'
  done < "$TMP_EXTRACT/$ENV_TEMPLATE"
  if [[ -n $NEW_KEYS ]]; then
    { echo ""; echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"; } >> "$TARGET_DIR/.env"
    echo "    New .env keys added with their defaults (bottom of $TARGET_DIR/.env):"
    printf '%s' "$NEW_KEYS" | sed 's/^/      /'
  else
    echo "    No new .env keys."
  fi
  echo "    All your existing values were left exactly as they were."
elif [[ -f $TMP_EXTRACT/$ENV_TEMPLATE ]]; then
  cp "$TMP_EXTRACT/$ENV_TEMPLATE" "$TARGET_DIR/.env"
  chmod 600 "$TARGET_DIR/.env"
  echo "    No existing .env — created one from $ENV_TEMPLATE."
fi

# ---------------------------------------------------------------- start / restart ---
env_value() { # key file
  [[ -f $2 ]] || return 0
  grep -E "^$1=" "$2" | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'
}
PASSWORD=$(env_value WEB_AUTHENTICATION_PASSWORD "$TARGET_DIR/.env")

echo ""
if [[ -z $PASSWORD || $PASSWORD == "$PLACEHOLDER_PASSWORD" ]]; then
  echo "==> Files are in place, but the web login password is still the placeholder, so nothing was started."
  echo "    Set WEB_AUTHENTICATION_USERNAME / WEB_AUTHENTICATION_PASSWORD in:"
  echo "      $TARGET_DIR/.env"
  echo "    then run the same install/update command again to start it."
  exit 0
fi

cd "$TARGET_DIR"
image_id() { docker image inspect -f '{{.Id}}' "$(docker compose config --images | head -n1)" 2>/dev/null || true; }
BEFORE_IMAGE=$(image_id)
echo "==> Pulling the latest image"
if ! docker compose pull --quiet "$SERVICE"; then
  echo "    Couldn't pull — carrying on with the image already on this machine." >&2
fi
AFTER_IMAGE=$(image_id)

RECREATE=()
if [[ -s $NEW_LIST || -s $UPDATED_LIST ]]; then
  # policies.json is a bind-mounted file Firefox only reads at start, so file changes need a recreate
  RECREATE=(--force-recreate)
  echo "==> Project files changed — recreating the container so Firefox picks them up"
elif [[ -n $BEFORE_IMAGE && $BEFORE_IMAGE != "$AFTER_IMAGE" ]]; then
  echo "==> New image — recreating the container"
elif [[ -z $(docker compose ps -q "$SERVICE" 2>/dev/null) ]]; then
  echo "==> Starting the container"
else
  echo "==> Nothing changed — leaving a running container as it is"
fi
fail() {
  echo "    Firefox didn't come up: $1" >&2
  echo "---- last log lines ----" >&2
  docker compose logs --tail 40 "$SERVICE" >&2 || true
  echo "------------------------" >&2
  echo "    Fix .env (or the edited files listed above) and run the install/update command again." >&2
  exit 1
}
docker compose up -d --remove-orphans "${RECREATE[@]}" || fail "docker compose up failed (see the error above)"

echo "==> Waiting up to ${START_TIMEOUT}s for the container to come up"
deadline=$(( $(date +%s) + START_TIMEOUT ))
status="not checked"
stable=0
while (( $(date +%s) < deadline )); do
  cid=$(docker compose ps -q "$SERVICE" 2>/dev/null || true)
  if [[ -n $cid ]]; then
    state=$(docker inspect -f '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$cid" 2>/dev/null || echo "missing none")
    run=${state% *} health=${state#* }
    status="container $run, health: $health"
    if [[ $run == running ]]; then
      if [[ $health == healthy ]] || { [[ $health == none ]] && (( ++stable >= 3 )); }; then
        echo "    $status"
        echo ""
        echo "==> Done. Firefox is running on port 5800."
        echo "    Logs:  cd $(pwd) && docker compose logs -f"
        exit 0
      fi
    else
      stable=0
    fi
  else
    status="container not created"
  fi
  sleep 3
done

fail "$status"
